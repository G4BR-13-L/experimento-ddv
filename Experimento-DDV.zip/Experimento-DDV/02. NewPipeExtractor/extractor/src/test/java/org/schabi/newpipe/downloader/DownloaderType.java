package org.schabi.newpipe.downloader;

public enum DownloaderType {
    REAL, MOCK, RECORDING
}